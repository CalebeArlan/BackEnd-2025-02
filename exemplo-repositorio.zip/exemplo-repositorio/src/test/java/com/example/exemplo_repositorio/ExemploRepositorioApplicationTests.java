package com.example.exemplo_repositorio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploRepositorioApplicationTests {

	@Test
	void contextLoads() {
	}

}
