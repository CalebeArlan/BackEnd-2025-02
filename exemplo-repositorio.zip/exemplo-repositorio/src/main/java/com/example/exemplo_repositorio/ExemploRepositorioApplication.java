package com.example.exemplo_repositorio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploRepositorioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploRepositorioApplication.class, args);
	}

}
