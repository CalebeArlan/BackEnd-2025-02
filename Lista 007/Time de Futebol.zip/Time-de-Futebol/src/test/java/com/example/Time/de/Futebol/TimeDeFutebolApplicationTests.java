package com.example.Time.de.Futebol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeDeFutebolApplicationTests {

	@Test
	void contextLoads() {
	}

}
