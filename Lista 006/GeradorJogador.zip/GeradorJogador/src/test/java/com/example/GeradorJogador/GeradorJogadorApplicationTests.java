package com.example.GeradorJogador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeradorJogadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
